#include <MemoryFree.h>

#include <stdlib.h> 
#include <USB/PluggableUSBSerial.h>
#include "rtos/Thread.h"
extern "C" char* sbrk(int incr);


long freeMemory( long*p1, long *p2) {
  char top = 32;
  char* ptr =(char*) malloc(1);  // try to allocate 1 byte
  if (ptr == NULL) return 0;
  char stack_var;
  long tmp = (char*)&stack_var - (char*)ptr;
  free(ptr);
  return tmp;

}

extern "C" char __end__;
extern uint32_t __StackTop;    // top of stack
extern uint32_t __StackLimit;
// Helper to get current heap end
uintptr_t getHeapEnd() {
    return (uintptr_t)sbrk(0);
}
uintptr_t getHeapStart()
{
  return (uintptr_t) &__end__;
}
uintptr_t getHeapLatest()
{
  return (uintptr_t)malloc(1);
}
uintptr_t getStackStart()
{
  return (uintptr_t)(&__StackTop);
}
uintptr_t getStackEnd()
{
  return (uintptr_t)&__StackLimit;
}
void printFreeRAM()
{
  uintptr_t stack = getStackEnd();
  uintptr_t* latestHeap = (uintptr_t*) malloc(1);
  Serial.print(F("Free space:"));
  Serial.print((float)((stack - (uintptr_t)latestHeap)*100 / 1024) /100);
  Serial.println(F(" kB"));
  free(latestHeap);
}

// Prints free stack for all threads and min SP
void printThreadStacks() {
    const uint32_t maxThreads = 16;
    osThreadId_t threads[maxThreads];
    uint32_t count = osThreadEnumerate(threads, maxThreads);

    uintptr_t minSP = UINTPTR_MAX;

    Serial.print(F("Threads ("));
    Serial.print(count);
    Serial.println(F("):"));

    for (uint32_t i = 0; i < count; i++) {
        osThreadId_t t = threads[i];
        size_t stackSize = osThreadGetStackSize(t);
        size_t freeStack = osThreadGetStackSpace(t);
        uintptr_t approxSP = (uintptr_t)t + stackSize - freeStack;

        if (approxSP < minSP) minSP = approxSP;

       Serial.print(F("  Thread "));
        Serial.print(i);
        Serial.print(F(" TCB="));
        Serial.print((uintptr_t)t, HEX);
        Serial.print(F(" StackSize="));
        Serial.print(stackSize,HEX);
        Serial.print(F(" FreeStack="));
        Serial.print(freeStack,HEX);
        Serial.print(F(" ApproxSP=0x"));
        Serial.println(approxSP, HEX);
      
      }

    //Serial.print(F("Minimum SP among all threads: 0x"));
    //Serial.println(minSP, HEX);

    // Compute approximate free SRAM
    uintptr_t heap_end = getHeapEnd();
    size_t freeSRAM = (minSP > heap_end) ? (minSP - heap_end) : 0;
    Serial.print(F("Stack start:  0x"));
    Serial.println(getStackStart(), HEX);
    Serial.print(F("Stack end:    0x"));
    Serial.println(getStackEnd(),HEX);
    Serial.print(F("Heap start:   0x"));
    Serial.println(getHeapStart(), HEX);
    Serial.print(F("Heap end:     0x"));
    Serial.println(heap_end, HEX);
    //Serial.print(F("Heap latest:  0x"));
    //Serial.println(getHeapLatest(), HEX);
    printFreeRAM();
    Serial.print(F("Approx. free SRAM between heap and threads: "));
    Serial.println(F(freeSRAM));
    Serial.println();
}
