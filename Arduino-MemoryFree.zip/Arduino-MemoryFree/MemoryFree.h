// memoryFree header
// From http://www.arduino.cc/cgi-bin/yabb2/YaBB.pl?num=1213583720/15
// ...written by user "mem".

#ifndef	MEMORY_FREE_H
#define MEMORY_FREE_H

#include <stdlib.h> 
#include <USB/PluggableUSBSerial.h>
#include "rtos/Thread.h"

long freeMemory(long*,long*);

uintptr_t getHeapEnd();
uintptr_t getHeapStart();
uintptr_t getHeapLatest();
void printFreeRAM();


uintptr_t getStackStart();
uintptr_t getStackEnd();
void printThreadStacks();
#endif
